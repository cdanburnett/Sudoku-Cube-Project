Thank you for grading my submission.

There are more instructions in the word document, but just for brevity, this also instructs you on how to run it.

There are two methods:
right click the main.py and select run with python.
	A window will open, displaying the output of the code. It should look like the Sample Output.txt.
	It prints that the cube was solved, and the moves needed to solve.

Use Visual Studio code

o	You have already unzipped the file

o	The file is called A-Star-Cube-Project

o	Inside this file you will find the three .py files used, as well as the project file.

o	Launch VS Code, and open the A-Star-Cube-Project folder.

o	Ensure you have python3 installed

o	You can run it in VS Code using the run program button in the top right corner.

o	You may be prompted for whether you trust the author, respond as needed to run the code (just this once, or 			always)

o	This will output to the terminal in VS Code, and terminate after you press enter. This program has been known to 		eat into SSD space for some unknown reason when K > 10. This is not permanent and goes away when the program is 		terminated. 

o	You can also run the code by double clicking main.py, assuming you have python3 installed. Or right-click main.py 	and select “run with” if python is not your default method.

class Face:
    def __init__(self, values=None):
        self.values = values

    # --- helper methods ---
    def _get(self, indices):
        return [self.values[i] for i in indices]

    def _set(self, indices, new_vals):
        for idx, val in zip(indices, new_vals):
            self.values[idx] = val

    # --- named rows and columns ---
    @property
    def top_row(self):
        return self._get([0, 1, 2])

    @top_row.setter
    def top_row(self, new_vals):
        self._set([0, 1, 2], new_vals)

    @property
    def middle_row(self):
        return self._get([3, 4, 5])

    @middle_row.setter
    def middle_row(self, new_vals):
        self._set([3, 4, 5], new_vals)

    @property
    def bottom_row(self):
        return self._get([6, 7, 8])

    @bottom_row.setter
    def bottom_row(self, new_vals):
        self._set([6, 7, 8], new_vals)

    @property
    def left_col(self):
        return self._get([0, 3, 6])

    @left_col.setter
    def left_col(self, new_vals):
        self._set([0, 3, 6], new_vals)

    @property
    def middle_col(self):
        return self._get([1, 4, 7])

    @middle_col.setter
    def middle_col(self, new_vals):
        self._set([1, 4, 7], new_vals)

    @property
    def right_col(self):
        return self._get([2, 5, 8])

    @right_col.setter
    def right_col(self, new_vals):
        self._set([2, 5, 8], new_vals)




